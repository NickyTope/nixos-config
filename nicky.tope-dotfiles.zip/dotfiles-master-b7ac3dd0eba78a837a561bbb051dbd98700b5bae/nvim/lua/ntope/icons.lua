-- ttf-twemoji
local icons = {
	error = "🚫",
	warning = "🔥",
	info = "🪧",
	hint = "📣",
	ok = "🚀",
	action = "💡",
	changed = "🔄",
	staged = "📦",
	untracked = "🆕",
	moved = "🔃",
	unmerged = "🔄",
	ignored = "🚫",
	unknown = "❓",
}

return icons
