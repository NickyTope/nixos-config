return {
	{ "mitsuhiko/vim-jinja", ft = "jinja" },
	{ "stephpy/vim-yaml", ft = "yaml" },
	{ "vim-scripts/groovy.vim", ft = "groovy" },
	{ "chrisbra/csv.vim", ft = "csv" },
	{ "kkharji/sqlite.lua", ft = "sqlite" },
	"vim-scripts/nginx.vim",
}
