return {
	"luckasRanarison/clear-action.nvim",
	opts = {
		signs = {
			show_label = true,
			enable = false,
		},
		mappings = {
			code_action = "<leader>la",
		},
	},
}
