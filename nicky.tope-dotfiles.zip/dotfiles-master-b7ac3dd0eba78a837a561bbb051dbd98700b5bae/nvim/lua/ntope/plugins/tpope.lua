return {
	{ "tpope/vim-fugitive", keys = {
		{ "<leader>gs", "<cmd>G|18wincmd_<cr>", desc = "Git Status" },
	} },
	{ "tpope/vim-rhubarb", keys = {
		{ "<leader>gh", "<cmd>GBrowse<cr>", desc = "Git Browse" },
	} },
}
